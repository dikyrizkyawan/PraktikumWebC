<?php
$koneksi = new mysqli('localhost', 'root', '', 'prak_pbw_sort');

$selected_jenis="";
$search_keyword="";
$sort = "ASC";
if (isset($_POST["search"])) {
    $selected_jenis = $_POST['selected_jenis'];
    $search_keyword = $_POST['search_keyword'];
    $sort = $_POST['sort'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas Modul 11: Sort & Filter</title>
</head>
<style type="text/css">
	fieldset{
		width: 25%; margin: auto; border: 1px solid;
	}
	.table{
		border-collapse: collapse; border: 1px solid black; text-align: center; margin: auto;
	}
	.table td{
		border: 1px solid; padding: 5px;
	}
</style>
<body>
<form action="" method="POST">
<fieldset style="width: 25%; margin: auto;">
	<table>
		<tr>
			<td>Keyword</td>
			<td>: <input type="text" name="search_keyword" id="search_keyword" value="<?php echo $search_keyword; ?>"></td>
		</tr>
		<tr>
			<td>Jenis</td>
			<td>: <select name="selected_jenis" id="selected_jenis" class="form-control">
                    <option value="">Mahasiswa / Dosen</option>
                    <option value="Mahasiswa" <?php if ($selected_jenis=="Mahasiswa"){ echo "selected"; } ?>>Mahasiswa</option>
                    <option value="Dosen" <?php if ($selected_jenis=="Dosen"){ echo "selected"; } ?>>Dosen</option>
                  </select></td>
		</tr>
		<tr>
			<td>Sort By (NI)</td>
			<td>: <input type="radio" name="sort" value="ASC" <?php if ($sort=="ASC"){ echo "checked"; } ?>>Ascending  <input type="radio" name="sort" value="DESC" <?php if ($sort=="DESC"){ echo "checked"; } ?>>Descending</td>
		</tr>
        <td><button id="search" name="search">Go</button></td>
	</table>
</fieldset> 
</form>
<br>
<fieldset>
    <legend>Data SIMAK</legend>
        <table border="1" class="table">
            <tr>
                <th>Nomor Induk (NI)</th>
                <th>Nama</th>
                <th>Jenis Kelamin</th>
                <th>Jenis</th>		
            </tr>
            <?php
            $jenis = '%'. $selected_jenis .'%';
            $keyword = '%'. $search_keyword .'%';
            $query = "SELECT * FROM user WHERE jenis LIKE ? AND (nama LIKE ? OR jk LIKE ? OR nomor LIKE ? OR jenis LIKE ?) ORDER BY nomor $sort";
            $exe = $koneksi->prepare($query);
            $exe->bind_param('sssss', $jenis, $keyword, $keyword, $keyword, $keyword);
            $exe->execute();
            $result = $exe->get_result();
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $pnomor = $row['nomor'];
                    $pnama = $row['nama'];
                    $pjk = $row['jk'];
                    $pjenis = $row['jenis'];
            ?>
            <tr>
                <td><?php echo $pnomor; ?></td>
                <td><?php echo $pnama; ?></td>
                <td><?php echo $pjk; ?></td>
                <td><?php echo $pjenis; ?></td>
            </tr>
            <?php } } else { ?> 
		    <tr>
		        <td colspan='4'>Tidak ada data ditemukan</td>
		    </tr>
		    <?php } ?>
        </table>
</fieldset>
</body>
</html>