-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2020 at 05:24 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prak_pbw_sort`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `nomor` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jk` enum('Laki-Laki','Perempuan') NOT NULL,
  `jenis` enum('Mahasiswa','Dosen') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`nomor`, `nama`, `jk`, `jenis`) VALUES
(1234567890, 'Ibu Budi', 'Perempuan', 'Dosen'),
(1234567891, 'Bapak Budi', 'Laki-Laki', 'Dosen'),
(1234567892, 'Mas Wawan', 'Laki-Laki', 'Dosen'),
(1234567893, 'Mas Jo', 'Laki-Laki', 'Dosen'),
(1234567894, 'Mbak Juminten', 'Perempuan', 'Dosen'),
(1234567895, 'Ibu Yeyen', 'Perempuan', 'Dosen'),
(1708561054, 'Adi', 'Laki-Laki', 'Mahasiswa'),
(1708561055, 'Diky Rizky Awan', 'Laki-Laki', 'Mahasiswa'),
(1708561056, 'Hendra', 'Laki-Laki', 'Mahasiswa'),
(1708561057, 'Ayut', 'Perempuan', 'Mahasiswa'),
(2123456789, 'Dosen Baru', 'Laki-Laki', 'Dosen');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`nomor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
