<?php
$koneksi = mysqli_connect('localhost', 'root', '', 'prak_pbw_session');
session_start();
?>